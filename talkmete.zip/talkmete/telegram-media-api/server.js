 const express = require('express');
const multer = require('multer');
const axios = require('axios');
const FormData = require('form-data');
const cors = require('cors');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

// In-Memory বা Database-এ media metadata ম্যাপিং (প্রয়োজনে Redis/MongoDB/Firebase-এ রাখতে পারেন)
const mediaStore = new Map();

// Multer Storage Configuration (RAM Buffer - ডিস্কে ফাইল জমা হয়ে জায়গা নষ্ট হবে না)
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: (parseInt(process.env.MAX_FILE_SIZE_MB) || 50) * 1024 * 1024 // ডিফল্ট 50MB
  }
});

// Environment / Dynamic Config
let config = {
  enabled: true,
  botToken: process.env.TELEGRAM_BOT_TOKEN || '',
  channelId: process.env.TELEGRAM_CHANNEL_ID || '',
  mediaBaseUrl: process.env.MEDIA_BASE_URL || 'http://localhost:5000',
  maxFileSizeMB: parseInt(process.env.MAX_FILE_SIZE_MB) || 50
};

// ==========================================
// 1. ADMIN CONFIGURATION & TEST ENDPOINTS
// ==========================================

// Settings আপডেট (Admin Panel থেকে)
app.post('/api/admin/settings', (req, res) => {
  const { enabled, botToken, channelId, mediaBaseUrl, maxFileSizeMB } = req.body;
  if (enabled !== undefined) config.enabled = enabled;
  if (botToken) config.botToken = botToken;
  if (channelId) config.channelId = channelId;
  if (mediaBaseUrl) config.mediaBaseUrl = mediaBaseUrl;
  if (maxFileSizeMB) config.maxFileSizeMB = maxFileSizeMB;

  return res.json({ success: true, message: 'Settings updated successfully' });
});

// Telegram Connection Test
app.post('/api/telegram/test-connection', async (req, res) => {
  const token = req.body.botToken || config.botToken;
  const channel = req.body.channelId || config.channelId;

  if (!token || !channel) {
    return res.status(400).json({ success: false, message: 'Bot Token এবং Channel ID আবশ্যক!' });
  }

  try {
    // ১. Bot Token যাচাই
    const meRes = await axios.get(`https://api.telegram.org/bot${token}/getMe`);
    if (!meRes.data.ok) {
      return res.status(400).json({ success: false, message: 'Invalid Telegram Bot Token!' });
    }
    const botInfo = meRes.data.result;

    // ২. Channel Access ও Admin Rights যাচাই
    const chatMemberRes = await axios.get(`https://api.telegram.org/bot${token}/getChatMember`, {
      params: { chat_id: channel, user_id: botInfo.id }
    });

    const status = chatMemberRes.data?.result?.status;
    if (status !== 'administrator' && status !== 'creator') {
      return res.status(403).json({
        success: false,
        message: 'বটটি চ্যানেলের Administrator নয়! চ্যানেল সেটিংসে গিয়ে বটকে অ্যাডমিন বানান।'
      });
    }

    return res.json({
      success: true,
      message: `সংযোগ সফল! বট: @${botInfo.username}, চ্যানেল অ্যাক্সেস আছে এবং বট অ্যাডমিন।`
    });
  } catch (error) {
    console.error('Test Connection Error:', error.response?.data || error.message);
    return res.status(500).json({
      success: false,
      message: 'টেলিগ্রাম সংযোগ ব্যর্থ হয়েছে। Channel ID বা Token সঠিক কিনা যাচাই করুন।'
    });
  }
});

// Test Upload
app.post('/api/telegram/test-upload', upload.single('file'), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ success: false, message: 'কোনো ফাইল সিলেক্ট করা হয়নি!' });
  }
  try {
    const formData = new FormData();
    formData.append('chat_id', config.channelId);
    formData.append('document', req.file.buffer, { filename: req.file.originalname });

    const tgRes = await axios.post(`https://api.telegram.org/bot${config.botToken}/sendDocument`, formData, {
      headers: formData.getHeaders()
    });

    return res.json({ success: true, message: 'টেস্ট ফাইল সফলভাবে টেলিগ্রামে আপলোড হয়েছে!', data: tgRes.data.result });
  } catch (error) {
    console.error('Test Upload Error:', error.response?.data || error.message);
    return res.status(500).json({ success: false, message: 'টেস্ট আপলোড ব্যর্থ হয়েছে!' });
  }
});

// ==========================================
// 2. CENTRALIZED MEDIA UPLOAD (POST /media/upload)
// ==========================================
app.post('/media/upload', upload.single('file'), async (req, res) => {
  try {
    if (!config.enabled) {
      return res.status(503).json({ success: false, message: 'Telegram Media Storage বর্তমানে বন্ধ আছে।' });
    }

    if (!req.file) {
      return res.status(400).json({ success: false, message: 'কোনো ফাইল পাওয়া যায়নি।' });
    }

    const { originalname, mimetype, size, buffer } = req.file;

    // ফাইল টাইপ সনাক্তকরণ
    let mediaType = 'document';
    let tgMethod = 'sendDocument';
    let fileField = 'document';

    if (mimetype.startsWith('image/')) {
      mediaType = 'image';
      tgMethod = 'sendPhoto';
      fileField = 'photo';
    } else if (mimetype.startsWith('video/')) {
      mediaType = 'video';
      tgMethod = 'sendVideo';
      fileField = 'video';
    } else if (mimetype.startsWith('audio/')) {
      mediaType = 'audio';
      tgMethod = 'sendAudio';
      fileField = 'audio';
    }

    // Telegram Bot API-তে পাঠানো
    const formData = new FormData();
    formData.append('chat_id', config.channelId);
    formData.append(fileField, buffer, { filename: originalname, contentType: mimetype });

    const tgResponse = await axios.post(
      `https://api.telegram.org/bot${config.botToken}/${tgMethod}`,
      formData,
      { headers: formData.getHeaders() }
    );

    if (!tgResponse.data.ok) {
      throw new Error('Telegram Upload Failed');
    }

    const result = tgResponse.data.result;
    let fileId = '';

    // Telegram Response থেকে file_id এক্সট্র্যাক্ট করা
    if (mediaType === 'image') {
      const photos = result.photo;
      fileId = photos[photos.length - 1].file_id; // সর্বোচ্চ রেজোলিউশনের ছবি
    } else if (mediaType === 'video') {
      fileId = result.video.file_id;
    } else if (mediaType === 'audio') {
      fileId = result.audio.file_id;
    } else {
      fileId = result.document.file_id;
    }

    // ইউনিক ইন্টারনাল Media ID তৈরি
    const mediaId = 'media_' + Date.now().toString(36) + Math.random().toString(36).substring(2, 7);
    const stableMediaUrl = `${config.mediaBaseUrl}/media/${mediaId}`;

    // স্টোরেজে ম্যাপিং সেভ
    const mediaRecord = {
      mediaId,
      fileId,
      mediaType,
      fileName: originalname,
      mimeType: mimetype,
      size,
      mediaUrl: stableMediaUrl,
      createdAt: Date.now()
    };
    mediaStore.set(mediaId, mediaRecord);

    // ক্লায়েন্টকে মেটাডাটা রিটার্ন
    return res.status(200).json({
      success: true,
      mediaId,
      type: mediaType,
      fileName: originalname,
      mimeType: mimetype,
      size,
      mediaUrl: stableMediaUrl
    });

  } catch (error) {
    console.error('Upload Error:', error.response?.data || error.message);
    return res.status(500).json({
      success: false,
      message: 'Upload failed. Please try again.',
      error: error.message
    });
  }
});

// ==========================================
// 3. MEDIA DELIVERY / RETRIEVAL (GET /media/:mediaId)
// ==========================================
app.get('/media/:mediaId', async (req, res) => {
  const { mediaId } = req.params;
  const record = mediaStore.get(mediaId);

  if (!record) {
    return res.status(404).send('Media Not Found');
  }

  try {
    // Telegram থেকে ফাইল পাথ বের করা
    const fileRes = await axios.get(`https://api.telegram.org/bot${config.botToken}/getFile`, {
      params: { file_id: record.fileId }
    });

    if (!fileRes.data.ok) {
      return res.status(404).send('Telegram File Missing');
    }

    const filePath = fileRes.data.result.file_path;
    const downloadUrl = `https://api.telegram.org/file/bot${config.botToken}/${filePath}`;

    // ক্লায়েন্টের কাছে মিডিয়া স্ট্রিম করা
    const streamRes = await axios({
      method: 'GET',
      url: downloadUrl,
      responseType: 'stream'
    });

    res.setHeader('Content-Type', record.mimeType);
    res.setHeader('Cache-Control', 'public, max-age=31536000, immutable'); // ব্রাউজার ক্যাশিং
    streamRes.data.pipe(res);

  } catch (error) {
    console.error('Media Delivery Error:', error.message);
    return res.status(500).send('Error streaming media');
  }
});

// সার্ভার স্টার্ট
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Telegram Media API Server running on port ${PORT}`);
});